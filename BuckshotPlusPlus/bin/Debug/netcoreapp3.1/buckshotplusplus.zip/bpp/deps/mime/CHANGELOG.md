# Changelog

## v1.5.0

  * Compare extensions in a case-insensitive way (see
    [elixir-plug/mime#38](https://github.com/elixir-plug/mime/issues/38)).
