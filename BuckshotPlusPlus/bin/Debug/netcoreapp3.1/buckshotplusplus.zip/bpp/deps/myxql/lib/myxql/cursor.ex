defmodule MyXQL.Cursor do
  @moduledoc false

  defstruct [:ref]
end
